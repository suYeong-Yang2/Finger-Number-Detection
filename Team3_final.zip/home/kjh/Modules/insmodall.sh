insmod fpga_interface_driver.ko
insmod fpga_dot_driver.ko
insmod fpga_buzzer_driver.ko
insmod fpga_fnd_driver.ko
insmod fpga_led_driver.ko
insmod fpga_text_lcd_driver.ko
