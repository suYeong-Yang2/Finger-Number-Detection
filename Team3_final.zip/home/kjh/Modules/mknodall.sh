mknod /dev/fpga_dot c 262 0
mknod /dev/fpga_buzzer c 264 0
mknod /dev/fpga_fnd c 261 0
mknod /dev/fpga_led c 260 0
mknod /dev/fpga_text_lcd c 263 0
